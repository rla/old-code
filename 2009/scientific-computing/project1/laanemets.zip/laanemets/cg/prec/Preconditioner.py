class Preconditioner:
    
    """The base class for precoditioners."""
    
    pass